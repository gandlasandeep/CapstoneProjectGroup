package com.hcl.repositry;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.hcl.model.CardType;

@Repository
public interface ICardTypeDAO extends JpaRepository<CardType, Integer>{

}
