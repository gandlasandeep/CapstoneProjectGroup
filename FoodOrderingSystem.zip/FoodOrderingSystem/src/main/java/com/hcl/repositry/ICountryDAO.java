package com.hcl.repositry;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hcl.model.Country;
@Repository
public interface ICountryDAO extends JpaRepository<Country, Integer> {

}
