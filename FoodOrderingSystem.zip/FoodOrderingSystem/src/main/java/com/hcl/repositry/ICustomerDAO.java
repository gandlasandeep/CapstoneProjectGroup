package com.hcl.repositry;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.hcl.model.Customer;

@Repository
public interface ICustomerDAO extends JpaRepository<Customer, Integer>{
	// @Query(value="SELECT * FROM customer where email=?1 and password=?2",nativeQuery=true)
	 public Customer findByEmailAndPassword(String email,String password);
}
