package com.hcl.model;

import javax.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "address")
public class Address {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "address_id")
	private int addressId;
	
	@NotNull(message = "StreetName cannot be null")
	@Size(min=6 ,message="six characters needed")
	@Column(name = "street_name")
	private String streetName;
	
	@NotNull(message = "HouseNo cannot be null")
	@Size(min=2,max=4, message="minimum 2 and maximum 4 characters needed")
	@Column(name = "house_no")
	private String houseNo;
	
	@NotNull(message = "City cannot be null")
	@Size(min=3, message="minimum 3  characters needed")
	@Column(name = "city")
	private String city;
	
	@NotNull(message = "pincode cannot be null")
	@Pattern(regexp="^[0-9]{6}",message="length must be 6")
	@Column(name = "pincode")
	private int pincode;

	@OneToOne
	private State state;

	@ManyToOne
	private Customer customer;

}
