package com.hcl.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.model.Customer;
import com.hcl.repositry.ICustomerDAO;
@Service
public class CustomerImpl implements ICustomer {
	@Autowired
	private ICustomerDAO cd;

	@Override
	public Customer addCustomer(Customer customer) {
		
	
		return cd.saveAndFlush(customer);
	}

	@Override
	public Customer getEmailAndPassword(String email, String password) {
		return cd.findByEmailAndPassword(email, password);
	}

	

}
