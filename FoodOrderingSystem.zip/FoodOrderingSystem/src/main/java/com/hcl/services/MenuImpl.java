package com.hcl.services;
import com.hcl.model.Menu;
import com.hcl.repositry.*;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MenuImpl implements IMenu
{
@Autowired
private IMenuDAO md;
@Autowired
private IRestuarant rd;
@Override
public List<Menu> getdetailsByRestuarant(int rid) {
	return md.findByRestuarant(rid);
}
@Override
public List<Menu> getFoodByName(String foodName) {
	
	return md.findByFoodName(foodName);
}
}
