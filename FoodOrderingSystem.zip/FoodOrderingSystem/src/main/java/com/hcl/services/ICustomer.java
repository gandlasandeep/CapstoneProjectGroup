package com.hcl.services;

import java.util.List;

import com.hcl.model.Customer;

public interface ICustomer 
{
	Customer addCustomer(Customer customer);
	Customer getEmailAndPassword(String email,String password);
}
