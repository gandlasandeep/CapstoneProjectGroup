package com.hcl.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.hcl.model.Menu;
import com.hcl.services.IMenu;
import com.hcl.services.IRestuarant;

@CrossOrigin
@RestController
@RequestMapping("/api/v2")
public class FoodController 
{
@Autowired
private  IRestuarant rs;
@Autowired
private IMenu m;

@GetMapping("/restuarantName/{rname}")
	public ResponseEntity<?> displayRestuarants(@PathVariable String rname) {
	System.out.println(rname);
	List<Menu> mList=rs.getResturant(rname);
	System.out.println(mList);
	if(mList!=null) {
    return new ResponseEntity<List<Menu>>(mList,HttpStatus.OK);
    }
	 return new ResponseEntity<String>("Restuarant Not Found",HttpStatus.NOT_FOUND);
}

@GetMapping("/searchByFood/{name}")
public ResponseEntity<List<Menu>> searchByResName(@PathVariable String name) 
{
	System.out.println("search Name"+name);
return new ResponseEntity<List<Menu>>(m.getFoodByName(name),HttpStatus.OK);
}
}
