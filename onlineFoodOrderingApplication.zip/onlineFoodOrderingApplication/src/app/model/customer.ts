export class Customer {

    customerId:number=0;
    firstName:string="";
    lastName: string="";
    email:string="";
    password: string="";
}
