export class Search
 {

    foodId:number=0;
    foodCategory:string="";
    foodName:string="";
   foodPrice:number=0;
   imageUrl: string="";
   restuarantId:number=0;
   restuarantName:string="";
   restuarantLocation:string="";
   quanity:number=0;
}
