import { Injectable } from '@angular/core';
import { Search } from '../model/search';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  constructor() { }
  cartArray: Array<Search> = [];
}
