import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Login } from 'src/app/model/login';
import { CredentialsService } from 'src/app/services/credentials.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router: Router, private service: CredentialsService) { }
  login2: Login = new Login();
  ngOnInit(): void {
  }
  model: any = {}


  login() {
    console.log(this.model)
    this.service.getLoginCredentails(this.login2).subscribe(data => {
      console.log(data + "login credentails...")
      this.service.setToken(data.token);
      console.log(localStorage.getItem("authToken"));
      this.service.submitted = true;
      this.router.navigateByUrl("/Adigas")
    },
      e => {
        console.log(e)
        alert("Please enter Correct credentials")
      }
    )
  }
}
