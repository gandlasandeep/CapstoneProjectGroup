import { Component, OnInit } from '@angular/core';
import { Search } from 'src/app/model/search';

import { CartService } from 'src/app/services/cart.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  subtotal1: number = 0;
  sum: any;
  totalqty: number = 0;
  subtotal: number = 0;
  cartEmptyMsg: string = "";
  isDisplay: boolean = false;

  constructor(private cartService: CartService) { }
  quantity: number = 1;
  cartArray: Array<any> = [];
  ngOnInit(): void {
    this.cartItemsDisplay()
  }

  cartItemsDisplay() {
    this.cartArray = this.cartService.cartArray
    console.log("from cart arry", this.cartArray)
    if (this.cartArray.length === 0) {
      this.cartEmptyMsg = "Your Cart is Empty!"
      this.isDisplay = true;
    }
  }

  // calcQuantity(result:number,obj:Search){

  //   this.quantity;
  //  // console.log(obj.quantity+"object Quantity value.........")
  //   if(result==0){
  //     this.quantity=this.quantity+1
  //     obj.quanity=this.quantity
  //     console.log(obj.quanity+"object Quantity value.........")
  //   }
  //   if(result==1){
  //     this.quantity=this.quantity-1
  //     obj.quanity=this.quantity
  //   }
  //   console.log(result)

  // }
  removeCartItem(obj: any) {
    this.cartService.cartArray.splice;
    this.cartService.cartArray = this.cartArray.filter((i) => i != obj)
    alert("Item removed from the cart")
    this.cartItemsDisplay();


  }

  addQuantity(obj: any) {
    console.log("obj:  ", obj.quantity)
    console.log("this:  ", this.quantity)
    this.quantity = this.quantity + 1
    obj.quantity = this.quantity

  }
  subQuantity(obj: any) {
    this.quantity = this.quantity - 1
    obj.quantity = this.quantity
  }
  plus(item: any): any {
    if (item.quanity != 10) {
      item.quanity += 1;
      this.subtotal1 = 1 * item.foodPrice;
      this.sum = this.sum + this.subtotal1;
      console.log(this.sum);
      console.log(this.totalqty);
      return this.totalqty += 1;

    }
  }

  //To decrease the quantity
  minus(item: Search): any {
    if (item.quanity != 1) {
      item.quanity -= 1;
      this.subtotal = -1 * item.foodPrice;
      this.sum = this.sum + this.subtotal;
      console.log(this.sum);
      return this.totalqty -= 1;
    }
  }
}

