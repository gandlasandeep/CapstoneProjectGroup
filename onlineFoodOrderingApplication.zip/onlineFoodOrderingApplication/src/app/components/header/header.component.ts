import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Customer } from 'src/app/model/customer';
import { Search } from 'src/app/model/search';
import { CredentialsService } from 'src/app/services/credentials.service';
import { MenuService } from 'src/app/services/menu.service';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  total_price: number = 0;
  total_quantity: number = 0;
  foodName: string = "";
  dish: Array<any> = [];
  responseMessage: string = "";
  customer: Customer = new Customer();
  totalCost1: number = 0;
  totalQuantity: number = 0;
  search: any;


  constructor(private service: MenuService, private service2: CredentialsService, private router: Router, private builder: FormBuilder) { }

  ngOnInit(): void {
    this.cartAmount(),
      this.buildForm();
  }
  buildForm() {
    this.search = this.builder.group({
      foodName: ['', [Validators.required]]
    })
  }
  //To Search Food
  searchFood(name: string) {
    this.service.getFoodByName(name).subscribe((data) => {
      this.service.b = true;
      console.log(name + "passed data")
      console.log(data + "search response..")
      this.service.foodArray = data;
      this.router.navigateByUrl("/searchPage")
      console.log("mydata", this.service.foodArray);
    },
      e => {
        console.log(e);
      })
  }

  isToken: boolean = false;
  isTokenPresent(): any {
    if (this.service2.getToken() != null) {
      return this.isToken = true;
    }
    return false;
  }

  LogOut() {

    this.service2.removeToken();
    this.router.navigateByUrl("/Adigas")
  }

  //to put amount
  cartAmount() {
    this.service.on<number>().subscribe(
      data => {
        this.total_price = data;

      }
    )
    this.service.on1<number>().subscribe(
      data => {
        this.total_quantity = data
      }
    )
  }
  //to cart page
  redirectCart() {
    this.router.navigateByUrl("/cart")
  }
}
