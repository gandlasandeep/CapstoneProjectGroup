import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

function symbolValidator(control: any) { //control = registerForm.get('password')
  if (control.hasError('required')) return null;
  if (control.hasError('minlength')) return null;
  if (control.hasError('maxlength')) return null;


  if (control.value.indexOf('@') > -1) {
    return null
  } else {
    return { symbol: true }
  }
}
@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {
  [x: string]: any;

  constructor(private builder: FormBuilder,
    private router: Router
  ) { }



  ngOnInit() {
    this.buildForm();


  }
  buildForm() {
    this.registerForm = this.builder.group({
      FirstName: ['', Validators.required, Validators.minLength(2)],

      LastName: ['', Validators.required, Validators.minLength(2)],
      email: ['', [Validators.required, Validators.email]],
      Country: ['', Validators.required],
      Street: ['', Validators.required, Validators.minLength(6)],
      City: ['', Validators.required, Validators.minLength(3)],

      State: ['', Validators.required],
      PinCode: ['', Validators.required, Validators.maxLength(6), Validators.minLength(6)],
      NameOnCard: ['', Validators.required, Validators.minLength(6)],
      cardNumber: ['', Validators.required, Validators.maxLength(16), Validators.minLength(16)],
      CVV: ['', Validators.required, Validators.maxLength(3), Validators.minLength(3)],



    })
  }



  register() {
    console.log(this.registerForm.value)
  }




  goBack() {
    let isCancel = confirm("Want to cancel Payment");
    if (isCancel == true) {
      this.router.navigateByUrl("/Adigas");
    }
  }
  success() {
    alert("Your Payment is Success")

    this.router.navigateByUrl("/Adigas");

  }


}