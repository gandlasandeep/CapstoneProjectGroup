export default class images{
    rname:string="";
    url:string="";
    name:string="";
    content:string="";
    price:string="";
}
