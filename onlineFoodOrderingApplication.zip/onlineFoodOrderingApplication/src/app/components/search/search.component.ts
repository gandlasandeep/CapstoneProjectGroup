import { Component, Input, OnInit } from '@angular/core';
import { Search } from 'src/app/model/search';
import { CartService } from 'src/app/services/cart.service';
import { MenuService } from 'src/app/services/menu.service';
import { HeaderComponent } from '../header/header.component';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {


  constructor(private service: MenuService, private cartService: CartService) { }
  ngOnInit(): void {
    this.method()
  }
  foodArr: Array<any> = [];

  method() {
    this.foodArr = this.service.foodArray;
    console.log("local search ts array" + this.foodArr)
    console.log("Service food array" + this.service.foodArray)
  }
  //regarding cart

  total: number = 0;
  quantity: number = 0;
  topCartDisplay(obj: any) {
    this.total = obj.foodPrice + this.total;
    this.service.totalCost = this.total;
    this.quantity = this.quantity + 1;
    this.service.emit<number>(this.total);
    this.service.emit1<number>(this.quantity);
    console.log(this.service.totalCost)

  }
  //To add to cart
  addToCart(obj: Search) {


    this.cartService.cartArray.push(obj)
    console.log(this.cartService.cartArray)
  }
}
