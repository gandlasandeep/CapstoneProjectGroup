import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, UrlSegment } from '@angular/router';
import { Search } from 'src/app/model/search';
import { CartService } from 'src/app/services/cart.service';
import { MenuService } from 'src/app/services/menu.service';
import images from '../images';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {
  menu: Array<any> = [];
  decision: string = '';
  name: string = "";
  display: Array<images> = [];
  constructor(private router: ActivatedRoute, private service: MenuService, private cartService: CartService) { }

  ngOnInit(): void {
    this.iterateroute();
  }
  getMenu(name: string) {
    this.service.getMenuList(name).subscribe((data) => {
      this.menu = data;
      console.log(this.menu);
    },
      e => {
        console.log(e);
      }
    )
  }

  iterateroute() {
    this.router.url.subscribe((url: UrlSegment[]) => {
      this.decision = url[0].path.toString();
      this.getMenu(this.decision);
    });
  }
  //regarding cart

  total: number = 0;
  quantity: number = 0;
  topCartDisplay(obj: any) {
    this.total = obj.foodPrice + this.total;
    this.service.totalCost = this.total;
    this.quantity = this.quantity + 1;
    this.service.emit<number>(this.total);
    this.service.emit1<number>(this.quantity);
    console.log(this.service.totalCost)

  }
  //Add to cart
  addToCart(obj: Search) {


    this.cartService.cartArray.push(obj)
    console.log(this.cartService.cartArray)
  }
}



